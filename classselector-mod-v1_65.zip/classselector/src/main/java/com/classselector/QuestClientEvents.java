package com.classselector;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID, value = Dist.CLIENT)
public class QuestClientEvents {
    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (QuestKeys.OPEN.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new QuestScreen());
        }
        while (QuestKeys.SKILLS.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new SkillScreen());
        }
    }
}
