package com.classselector;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterItemDecorationsEvent;
import net.minecraftforge.client.IItemDecorator;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class RestrictClientEvents {
    /** Desenha um X vermelho sobre itens bloqueados para a classe do jogador local. */
    private static final IItemDecorator X_DECORATOR = new IItemDecorator() {
        @Override
        public boolean render(GuiGraphics g, Font font, ItemStack stack, int x, int y) {
            if (!RestrictClientState.isBlocked(stack)) return false;
            // X pequeno no canto inferior direito do item
            int x0 = x + 9, y0 = y + 9;
            for (int i = 0; i < 6; i++) {
                g.fill(RenderType.guiOverlay(), x0 + i, y0 + i, x0 + i + 2, y0 + i + 1, 0xFFE02020);
                g.fill(RenderType.guiOverlay(), x0 + 5 - i, y0 + i, x0 + 7 - i, y0 + i + 1, 0xFFE02020);
            }
            return true;
        }
    };

    @Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent
        public static void onDecorations(RegisterItemDecorationsEvent e) {
            for (Item it : ForgeRegistries.ITEMS) e.register(it, X_DECORATOR);
        }
    }

    @Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID, value = Dist.CLIENT)
    public static class ForgeBus {
        @SubscribeEvent
        public static void onTooltip(ItemTooltipEvent e) {
            if (RestrictClientState.isBlocked(e.getItemStack())) {
                e.getToolTip().add(1, Component.literal("[X] Bloqueado para a sua classe").withStyle(ChatFormatting.RED));
            }
        }
    }
}
